﻿using System;

namespace EncuestaApi.Entities
{
    public class EncuestaDetalle
    {
        public int Id { get; set; }
        public int EncuestaId { get; set; }
        public int PreguntaId { get; set; }
        public int Calificacion { get; set; }
        public DateTime FechaInicio { get; set; }
        public DateTime FechaFinal { get; set; }
        public int UsuarioId { get; set; }

        public virtual Encuesta Encuesta { get; set; }
        public virtual Pregunta Pregunta { get; set; }
        public virtual Usuario Usuario { get; set; }
    }
}