﻿using System.Collections.Generic;

namespace EncuestaApi.Entities
{
    public class Pregunta
    {
        public Pregunta()
        {
            EncuestaDetalle = new HashSet<EncuestaDetalle>();
        }

        public int Id { get; set; }
        public int EncuestaId { get; set; }
        public string Titulo { get; set; }
        public string TextoAyuda { get; set; }
        public int Orden { get; set; }

        public virtual Encuesta Encuesta { get; set; }
        public virtual ICollection<EncuestaDetalle> EncuestaDetalle { get; set; }
    }
}