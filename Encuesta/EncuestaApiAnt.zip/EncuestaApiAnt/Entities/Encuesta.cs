﻿using System;
using System.Collections.Generic;

namespace EncuestaApi.Entities
{
    public class Encuesta
    {
        public Encuesta()
        {
            EncuestaDetalle = new HashSet<EncuestaDetalle>();
            Pregunta = new HashSet<Pregunta>();
        }

        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public DateTime Fecha { get; set; }
        public int UsuarioId { get; set; }
        public bool Activo { get; set; }

        public virtual Usuario Usuario { get; set; }
        public virtual ICollection<EncuestaDetalle> EncuestaDetalle { get; set; }
        public virtual ICollection<Pregunta> Pregunta { get; set; }
    }
}