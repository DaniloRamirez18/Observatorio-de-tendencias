﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EncuestaApi.Entities
{
    public partial class Usuario
    {
        public Usuario()
        {
            Encuesta = new HashSet<Encuesta>();
            EncuestaDetalle = new HashSet<EncuestaDetalle>();
        }

        public int Id { get; set; }
        public int Identificacion { get; set; }
        public string Nombres { get; set; }
        public string Apellidos { get; set; }
        public string NombreUsuario { get; set; }
        public string Clave { get; set; }
        public DateTime FechaCreacion { get; set; }
        public DateTime? FechaUltimoAcceso { get; set; }
        public int PerfilId { get; set; }
        public string Avatar { get; set; }
        public bool Activo { get; set; }

        public virtual Perfil Perfil { get; set; }
        public virtual ICollection<Encuesta> Encuesta { get; set; }
        public virtual ICollection<EncuestaDetalle> EncuestaDetalle { get; set; }
    }
}