using AutoMapper;

namespace EncuestaApi.Mappers
{
    public class AautoMapperProfile : Profile
    {
        public AautoMapperProfile()
        {
            Mapper.Initialize(config =>
            {
                config.AddProfile<ProfileMapper>();
                config.AddProfile<QuestionMapper>();
                config.AddProfile<SurveyMapper>();
                config.AddProfile<SurveyDetailMapper>();
                config.AddProfile<UserMapper>();
            });
        }
    }
}