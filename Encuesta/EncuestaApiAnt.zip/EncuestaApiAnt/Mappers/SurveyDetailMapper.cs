﻿using AutoMapper;
using EncuestaApi.Entities;
using EncuestaApi.ViewModels;

namespace EncuestaApi.Mappers
{
    public class SurveyDetailMapper : Profile
    {
        public SurveyDetailMapper()
        {
            CreateMap<EncuestaDetalle, SurveyDetailViewModel>()
            .ForMember(d => d.Id, o => o.MapFrom(c => c.Id))
            .ForMember(d => d.SurveyId, o => o.MapFrom(c => c.EncuestaId))
            .ForMember(d => d.QuestionId, o => o.MapFrom(c => c.PreguntaId))
            .ForMember(d => d.Qualification, o => o.MapFrom(c => c.Calificacion))
            .ForMember(d => d.StartDate, o => o.MapFrom(c => c.FechaInicio))
            .ForMember(d => d.EndDate, o => o.MapFrom(c => c.FechaFinal))
            .ForMember(d => d.UserId, o => o.MapFrom(c => c.UsuarioId))

            .ForMember(d => d.Survey, o => o.MapFrom(c => c.Encuesta.Nombre))
            .ForMember(d => d.Question, o => o.MapFrom(c => c.Pregunta.Titulo))
            .ForMember(d => d.UserId, o => o.MapFrom(c => c.Usuario.NombreUsuario));

            CreateMap<SurveyDetailViewModel, EncuestaDetalle>()
            .ForMember(d => d.Id, o => o.MapFrom(c => c.Id))
            .ForMember(d => d.EncuestaId, o => o.MapFrom(c => c.SurveyId))
            .ForMember(d => d.PreguntaId, o => o.MapFrom(c => c.QuestionId))
            .ForMember(d => d.Calificacion, o => o.MapFrom(c => c.Qualification))
            .ForMember(d => d.FechaInicio, o => o.MapFrom(c => c.StartDate))
            .ForMember(d => d.FechaFinal, o => o.MapFrom(c => c.EndDate))
            .ForMember(d => d.UsuarioId, o => o.MapFrom(c => c.UserId));
        }
    }
}