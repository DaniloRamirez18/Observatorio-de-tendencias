﻿using System.IO;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using EncuestaApi.Helpers;

namespace EncuestaApi.Controllers
{
    [Authorize]
    [ApiController]
    [Produces("application/json")]
    [Route("[controller]")]
    public class UploadsController : Controller
    {
        private IHostingEnvironment _hostingEnvironment;
        private readonly AppSettings _appSettings;

        public UploadsController(IHostingEnvironment hostingEnvironment, IOptions<AppSettings> appSettings)
        {
            _hostingEnvironment = hostingEnvironment;
            _appSettings = appSettings.Value;
        }

        [AllowAnonymous]
        [HttpPost, DisableRequestSizeLimit]
        public ActionResult UploadFile()
        {
            try
            {
                var file = Request.Form.Files[0];
                string folderName = "Upload";
                string webRootPath = _hostingEnvironment.WebRootPath;
                string newPath = Path.Combine(webRootPath, folderName);
                if (!Directory.Exists(newPath))
                {
                    Directory.CreateDirectory(newPath);
                }
                if (file.Length > 0)
                {
                    string fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                    string fullPath = Path.Combine(newPath, fileName);
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }
                }
                return Json("Upload Successful.");
            }
            catch (System.Exception ex)
            {
                return Json("Upload Failed: " + ex.Message);
            }
        }

        [AllowAnonymous]
        [HttpPost("{foldername}"), DisableRequestSizeLimit]
        public ActionResult UploadFile(string foldername)
        {
            try
            {
                var file = Request.Form.Files[0];
                string folderName = foldername;
                //string webRootPath = _hostingEnvironment.WebRootPath;
                //string newPath = Path.Combine(webRootPath, folderName);
                var newPath = Path.Combine(_appSettings.StoragePath, folderName);
                if (!Directory.Exists(newPath))
                {
                    Directory.CreateDirectory(newPath);
                }
                if (file.Length > 0)
                {
                    string fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                    string fullPath = Path.Combine(newPath, fileName);
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }
                }
                return Json("Upload Successful.");
            }
            catch (System.Exception ex)
            {
                return Json("Upload Failed: " + ex.Message);
            }
        }

        [AllowAnonymous]
        [HttpPost("{foldername}/{document}"), DisableRequestSizeLimit]
        public ActionResult UploadFileDoc(string foldername, string document)
        {
            try
            {
                var file = Request.Form.Files[0];
                string folderName = foldername;
                var newPath = Path.Combine(_appSettings.StoragePath, folderName, document);
                if (!Directory.Exists(newPath))
                {
                    Directory.CreateDirectory(newPath);
                }
                if (file.Length > 0)
                {
                    string fileNameCur = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                    var e = Path.GetExtension(fileNameCur);
                    string fileName = document + e;
                    string fullPath = Path.Combine(newPath, fileName);
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }
                }
                return Json("Upload Successful.");
            }
            catch (System.Exception ex)
            {
                return Json("Upload Failed: " + ex.Message);
            }
        }

        [AllowAnonymous]
        [HttpPost("{foldername}/{type}/{document}"), DisableRequestSizeLimit]
        public ActionResult UploadFileDocType(string foldername, string type, string document)
        {
            try
            {
                var file = Request.Form.Files[0];
                string fileName = "";
                string folderName = foldername;
                var newPath = Path.Combine(_appSettings.StoragePath, folderName, document);
                if (!Directory.Exists(newPath))
                {
                    Directory.CreateDirectory(newPath);
                }
                if (file.Length > 0)
                {
                    string fina = file.Name;
                    string fileNameCur = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                    var e = Path.GetExtension(fileNameCur);
                    if (fina == document)
                    {
                        fileName = type.ToUpper() + document + e;
                    }
                    else
                    {
                        fileName = type.ToUpper() + fina + e;
                    }
                    string fullPath = Path.Combine(newPath, fileName);
                    using (var stream = new FileStream(fullPath, FileMode.Create))
                    {
                        file.CopyTo(stream);
                    }
                }
                return Json("Upload Successful.");
            }
            catch (System.Exception ex)
            {
                return Json("Upload Failed: " + ex.Message);
            }
        }
    }
}