using Microsoft.EntityFrameworkCore;
using EncuestaApi.Entities;
using EncuestaApi.Repository.Common;

namespace EncuestaApi.Contexts
{
    public class Context : DbContext, ISqlUnitOfWork
    {
        public Context(DbContextOptions<Context> options) : base(options) { }

        public virtual DbSet<Encuesta> Encuesta { get; set; }
        public virtual DbSet<EncuestaDetalle> EncuestaDetalle { get; set; }
        public virtual DbSet<Perfil> Perfil { get; set; }
        public virtual DbSet<Pregunta> Pregunta { get; set; }
        public virtual DbSet<Usuario> Usuario { get; set; }

        #region ISqlUnitOfWork Members
        public int Commit()
        {
            return SaveChanges();
        }
        public IBaseRepository<TEntity> GetBaseRepository<TEntity>() where TEntity : class
        {
            return new BaseRepository<TEntity>(this);
        }
        public IReadRepository<TEntity> GetReadRepository<TEntity>() where TEntity : class
        {
            return new ReadRepository<TEntity>(this);
        }

        public DbSet<TEntity> GetSet<TEntity>() where TEntity : class
        {
            return Set<TEntity>();
        }
        public DbContext GetContext()
        {
            return this;
        }
        #endregion
    }
}