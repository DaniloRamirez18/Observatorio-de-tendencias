﻿using NLog;
using System;
using System.Collections.Generic;

namespace EncuestaApi.Infrastructure
{
    public static class LogManager
    {
        private static readonly Logger _logger = NLog.LogManager.GetCurrentClassLogger();

        public static void LogException(Exception ex)
        {
            _logger.Error(ex);
        }

        public static void LogException(string error)
        {
            _logger.Error(error);
        }

        public static void LogInfo(string msg)
        {
            _logger.Info(msg);
        }

        public static void LogInfo(Dictionary<string, string> data)
        {
            _logger.Info(data);
        }
    }
}