﻿using System;
using System.Linq;
using System.Collections.Generic;
using EncuestaApi.Contexts;
using EncuestaApi.Entities;
using EncuestaApi.Helpers;
using EncuestaApi.Repository;

namespace EncuestaApi.Services
{
    public interface IProfileService
    {
        IEnumerable<Perfil> GetAll();
        IEnumerable<Perfil> GetAll(string includeProperties);
        Perfil GetById(int id);
        Perfil Create(Perfil entity);
        bool Update(Perfil entity);
        void Delete(int id);
    }
    public class ProfileService : IProfileService
    {
        private readonly string nameentity = "Profile";
        private readonly Context _context;
        private readonly IProfileRepository _entityRepository;
        private IQueryable<Perfil> entity;
        private Perfil entitycurrent;

        public ProfileService(Context context)
        {
            _context = context;
            _entityRepository = new ProfileRepository(_context);
        }

        public IEnumerable<Perfil> GetAll()
        {
            try
            {
                entity = _entityRepository.GetAll();
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entity;
        }

        public IEnumerable<Perfil> GetAll(string includeProperties)
        {
            try
            {
                entity = _entityRepository.GetAll(includeProperties);
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entity;
        }

        public Perfil GetById(int id)
        {
            try
            {
                entitycurrent = _entityRepository.GetById(id);
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entitycurrent;
        }

        public Perfil Create(Perfil entity)
        {
            try
            {
                if (entity != null)
                {
                    _entityRepository.Insert(entity);
                    var result = _entityRepository.UnitOfWork.Commit();
                }
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entity;
        }

        public bool Update(Perfil entity)
        {
            try
            {
                var entitycurrent = _entityRepository.GetById(entity.Id);
                if (entitycurrent == null)
                    throw new AppException(nameentity + "Not Found");

                // update entity properties
                entitycurrent.Nombre = entity.Nombre;

                _entityRepository.Update(entitycurrent);
                var result = _entityRepository.UnitOfWork.Commit();
                return result > 0;
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
                return false;
            }
        }

        public void Delete(int id)
        {
            try
            {
                var entitycurrent = _entityRepository.GetById(id);
                if (entitycurrent == null)
                    throw new AppException(nameentity + "Not Found");

                _entityRepository.Delete(entitycurrent);
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
        }
    }
}