﻿using System;
using System.Linq;
using System.Collections.Generic;
using EncuestaApi.Contexts;
using EncuestaApi.Entities;
using EncuestaApi.Helpers;
using EncuestaApi.Repository;

namespace EncuestaApi.Services
{
    public interface ISurveyService
    {
        IEnumerable<Encuesta> GetAll();
        IEnumerable<Encuesta> GetAll(string includeProperties);
        Encuesta GetById(int id);
        Encuesta Create(Encuesta entity);
        bool Update(Encuesta entity);
        void Delete(int id);
    }
    public class SurveyService : ISurveyService
    {
        private readonly string nameentity = "Surveyr";
        private readonly Context _context;
        private readonly ISurveyRepository _entityRepository;
        private IQueryable<Encuesta> entity;
        private Encuesta entitycurrent;

        public SurveyService(Context context)
        {
            _context = context;
            _entityRepository = new SurveyRepository(_context);
        }

        public IEnumerable<Encuesta> GetAll()
        {
            try
            {
                entity = _entityRepository.GetAll();
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entity;
        }

        public IEnumerable<Encuesta> GetAll(string includeProperties)
        {
            try
            {
                entity = _entityRepository.GetAll(includeProperties);
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entity;
        }

        public Encuesta GetById(int id)
        {
            try
            {
                entitycurrent = _entityRepository.GetById(id);
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entitycurrent;
        }

        public Encuesta Create(Encuesta entity)
        {
            try
            {
                if (entity != null)
                {
                    _entityRepository.Insert(entity);
                    var result = _entityRepository.UnitOfWork.Commit();
                }
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entity;
        }

        public bool Update(Encuesta entity)
        {
            try
            {
                var entitycurrent = _entityRepository.GetById(entity.Id);
                if (entitycurrent == null)
                    throw new AppException(nameentity + "Not Found");

                // update entity properties
                entitycurrent.Nombre = entity.Nombre;
                entitycurrent.Descripcion = entity.Descripcion;
                entitycurrent.Fecha = entity.Fecha;
                entitycurrent.UsuarioId = entity.UsuarioId;
                entitycurrent.Activo = entity.Activo;

                _entityRepository.Update(entitycurrent);
                var result = _entityRepository.UnitOfWork.Commit();
                return result > 0;
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
                return false;
            }
        }

        public void Delete(int id)
        {
            try
            {
                var entitycurrent = _entityRepository.GetById(id);
                if (entitycurrent == null)
                    throw new AppException(nameentity + "Not Found");

                _entityRepository.Delete(entitycurrent);
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
        }
    }
}