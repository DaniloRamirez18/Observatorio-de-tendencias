﻿using Microsoft.EntityFrameworkCore;

namespace EncuestaApi.Repository.Common
{
    public interface ISqlUnitOfWork : IUnitOfWork
    {
        DbSet<TEntity> GetSet<TEntity>() where TEntity : class;
        DbContext GetContext();
    }
}