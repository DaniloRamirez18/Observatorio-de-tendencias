﻿using System;
using Microsoft.EntityFrameworkCore;

namespace EncuestaApi.Repository.Common
{
    public abstract class Repository<TEntity> where TEntity : class
    {
        internal readonly DbSet<TEntity> _dbSet;
        internal readonly ISqlUnitOfWork _unitOfWork;
        protected Repository(ISqlUnitOfWork unitOfWork)
        {
            if (unitOfWork == null)
            {
                Infrastructure.LogManager.LogException("Unit of work is null");
                throw new ArgumentException("Unit of work is null");
            }
            _unitOfWork = unitOfWork;
            _dbSet = _unitOfWork.GetSet<TEntity>();
        }
    }
}