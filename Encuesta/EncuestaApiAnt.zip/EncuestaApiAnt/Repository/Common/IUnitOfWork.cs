﻿namespace EncuestaApi.Repository.Common
{
    public interface IUnitOfWork
    {
        int Commit();
        IBaseRepository<TEntity> GetBaseRepository<TEntity>() where TEntity : class;
        IReadRepository<TEntity> GetReadRepository<TEntity>() where TEntity : class;
    }
}