﻿using EncuestaApi.Entities;
using EncuestaApi.Repository.Common;

namespace EncuestaApi.Repository
{
    public interface ISurveyDetailRepository : IBaseRepository<EncuestaDetalle>
    {
    }
    public class SurveyDetailRepository : BaseRepository<EncuestaDetalle>, ISurveyDetailRepository
    {
        public SurveyDetailRepository(ISqlUnitOfWork unitOfWork) : base(unitOfWork)
        {
            Context = unitOfWork.GetContext();
        }
    }
}