﻿using EncuestaApi.Entities;
using EncuestaApi.Repository.Common;

namespace EncuestaApi.Repository
{
    public interface IUserRepository : IBaseRepository<Usuario>
    {
    }
    public class UserRepository : BaseRepository<Usuario>, IUserRepository
    {
        public UserRepository(ISqlUnitOfWork unitOfWork) : base(unitOfWork)
        {
            Context = unitOfWork.GetContext();
        }
    }
}