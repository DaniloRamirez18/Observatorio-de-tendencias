﻿using EncuestaApi.Entities;
using EncuestaApi.Repository.Common;

namespace EncuestaApi.Repository
{
    public interface IProfileRepository : IBaseRepository<Perfil>
    {
    }
    public class ProfileRepository : BaseRepository<Perfil>, IProfileRepository
    {
        public ProfileRepository(ISqlUnitOfWork unitOfWork) : base(unitOfWork)
        {
            Context = unitOfWork.GetContext();
        }
    }
}