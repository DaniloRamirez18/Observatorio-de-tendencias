﻿using System;
using System.Text;
using System.Linq;
using System.Security.Cryptography;

namespace EncuestaApi.Helpers
{
    public static class StringExtensions
    {
        public static string RemoveBlankSpaces(this string text)
        {
            return !string.IsNullOrEmpty(text) ? text.Replace(" ", "") : string.Empty;
        }
        public static int ToInt(this string text)
        {
            return string.IsNullOrEmpty(text) ? default(int) : Convert.ToInt32(text);
        }
        public static int ReturnInt(this string text)
        {
            int rta = 0;
            for (int i = 0; i < text.Length; i++)
            {
                if (text.Substring(i, 1) == " ")
                {
                    rta = i;
                }
            }
            return rta;
        }
        public static string ToSHA256(this string text)
        {
            var bytes = Encoding.Unicode.GetBytes(text);
            var hashstring = new SHA256Managed();
            var hash = hashstring.ComputeHash(bytes);
            var hashString = hash.Aggregate(string.Empty, (current, x) => current + String.Format("{0:x2}", x));
            return hashString;
        }

        //codificar base64
        public static string Base64_Encode(this string str)
        {
            byte[] encbuff = Encoding.UTF8.GetBytes(str);
            return Convert.ToBase64String(encbuff);
        }

        //Decodificar base64
        public static string Base64_Decode(this string str)
        {
            try
            {
                byte[] decbuff = Convert.FromBase64String(str);
                return Encoding.UTF8.GetString(decbuff);
            }
            catch
            {
                //si se envia una cadena si codificación base64, mandamos vacio
                return "";
            }
        }
    }
}