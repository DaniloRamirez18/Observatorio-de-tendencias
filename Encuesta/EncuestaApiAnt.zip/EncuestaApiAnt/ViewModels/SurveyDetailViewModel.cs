﻿using System;

namespace EncuestaApi.ViewModels
{
    public class SurveyDetailViewModel
    {
        public int Id { get; set; }
        public int SurveyId { get; set; }
        public int QuestionId { get; set; }
        public int Qualification { get; set; }
        public DateTime StartDate { get; set; } = DateTime.Now;
        public DateTime EndDate { get; set; } = DateTime.Now;
        public int UserId { get; set; }

        public string Survey { get; set; }
        public string Question { get; set; }
        public string User{ get; set; }
    }
}