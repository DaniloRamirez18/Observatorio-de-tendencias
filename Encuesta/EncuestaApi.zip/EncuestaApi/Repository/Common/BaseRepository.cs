﻿using System;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace EncuestaApi.Repository.Common
{
    public interface IBaseRepository<TEntity> : IReadRepository<TEntity> where TEntity : class
    {
        IUnitOfWork UnitOfWork { get; }
        void Insert(TEntity entity);
        void DeleteById(int id);
        void Delete(TEntity entity);
        void Update(TEntity entity);
    }
    public class BaseRepository<TEntity> : ReadRepository<TEntity>, IBaseRepository<TEntity> where TEntity : class
    {
        public IUnitOfWork UnitOfWork => _unitOfWork;
        public DbContext Context;
        public BaseRepository(ISqlUnitOfWork unitOfWork) : base(unitOfWork)
        {
        }

        public void Insert(TEntity entity)
        {
            if (entity == null)
            {
                Infrastructure.LogManager.LogException("No entity to insert");
                throw new ArgumentNullException("No entity to insert");
            }
            _dbSet.Add(entity);
        }

        public void DeleteById(int id)
        {
            var entityToDelete = _dbSet.Find(id);
            if (entityToDelete != null)
                Delete(entityToDelete);
            Context.SaveChanges();
        }
        
        public void Update(TEntity entity)
        {
            if (entity == null)
            {
                Infrastructure.LogManager.LogException("Entity to update is null");
                throw new ArgumentNullException("Entity to update is null");
            }
            var context = _unitOfWork.GetContext();
            if (context.Entry(entity).State == EntityState.Detached)
            {
                _dbSet.Attach(entity);
            }
            context.Entry(entity).State = EntityState.Modified;
        }

        public void Delete(TEntity entity)
        {
            if (entity == null)
            {
                Infrastructure.LogManager.LogException("Entity to delete is null");
                throw new ArgumentNullException("Entity to delete is null");
            }
            var context = _unitOfWork.GetContext();
            if (context.Entry(entity).State == EntityState.Detached)
            {
                _dbSet.Attach(entity);
            }
            _dbSet.Remove(entity);
            context.SaveChanges();
        }
    }
}