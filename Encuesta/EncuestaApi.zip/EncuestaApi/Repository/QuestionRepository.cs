﻿using EncuestaApi.Entities;
using EncuestaApi.Repository.Common;

namespace EncuestaApi.Repository
{
    public interface IQuestionRepository : IBaseRepository<Pregunta>
    {
    }
    public class QuestionRepository : BaseRepository<Pregunta>, IQuestionRepository
    {
        public QuestionRepository(ISqlUnitOfWork unitOfWork) : base(unitOfWork)
        {
            Context = unitOfWork.GetContext();
        }
    }
}