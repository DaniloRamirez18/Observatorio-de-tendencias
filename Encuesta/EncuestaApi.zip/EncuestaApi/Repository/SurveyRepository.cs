﻿using EncuestaApi.Entities;
using EncuestaApi.Repository.Common;

namespace EncuestaApi.Repository
{
    public interface ISurveyRepository : IBaseRepository<Encuesta>
    {
    }
    public class SurveyRepository : BaseRepository<Encuesta>, ISurveyRepository
    {
        public SurveyRepository(ISqlUnitOfWork unitOfWork) : base(unitOfWork)
        {
            Context = unitOfWork.GetContext();
        }
    }
}