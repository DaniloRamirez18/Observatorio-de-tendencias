namespace EncuestaApi.Helpers
{
    public class AppSettings
    {
        public string Secret { get; set; }
        public string StoragePath { get; set; }
     }
}