﻿using System;

namespace EncuestaApi.Helpers
{
    public class TransversalUtilities
    {
        public byte[] Base64ToByteArray(string base64String)
        {
            return Convert.FromBase64String(base64String);
        }
    }
}