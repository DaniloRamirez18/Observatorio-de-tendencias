﻿using AutoMapper;
using EncuestaApi.Entities;
using EncuestaApi.ViewModels;

namespace EncuestaApi.Mappers
{
    public class QuestionMapper : Profile
    {
        public QuestionMapper()
        {
            CreateMap<Pregunta, QuestionViewModel>()
            .ForMember(d => d.Id, o => o.MapFrom(c => c.Id))
            .ForMember(d => d.SurveyId, o => o.MapFrom(c => c.EncuestaId))
            .ForMember(d => d.Title, o => o.MapFrom(c => c.Titulo))
            .ForMember(d => d.TextHelp, o => o.MapFrom(c => c.TextoAyuda))
            .ForMember(d => d.Order, o => o.MapFrom(c => c.Orden))

            .ForMember(d => d.Survey, o => o.MapFrom(c => c.Encuesta.Nombre));

            CreateMap<QuestionViewModel, Pregunta>()
            .ForMember(d => d.Id, o => o.MapFrom(c => c.Id))
            .ForMember(d => d.EncuestaId, o => o.MapFrom(c => c.SurveyId))
            .ForMember(d => d.Titulo, o => o.MapFrom(c => c.Title))
            .ForMember(d => d.TextoAyuda, o => o.MapFrom(c => c.TextHelp))
            .ForMember(d => d.Orden, o => o.MapFrom(c => c.Order));
        }
    }
}