﻿using AutoMapper;
using EncuestaApi.Entities;
using EncuestaApi.ViewModels;

namespace EncuestaApi.Mappers
{
    public class ProfileMapper : Profile
    {
        public ProfileMapper()
        {
            CreateMap<Perfil, ProfileViewModel>()
            .ForMember(d => d.Id, o => o.MapFrom(c => c.Id))
            .ForMember(d => d.Name, o => o.MapFrom(c => c.Nombre))
            .ForMember(d => d.Description, o => o.MapFrom(c => c.Descripcion))
            .ForMember(d => d.Active, o => o.MapFrom(c => c.Activo));

            CreateMap<ProfileViewModel, Perfil>()
            .ForMember(d => d.Id, o => o.MapFrom(c => c.Id))
            .ForMember(d => d.Nombre, o => o.MapFrom(c => c.Name))
            .ForMember(d => d.Descripcion, o => o.MapFrom(c => c.Description))
            .ForMember(d => d.Activo, o => o.MapFrom(c => c.Active));
        }
    }
}