﻿using AutoMapper;
using EncuestaApi.Entities;
using EncuestaApi.ViewModels;
using EncuestaApi.Helpers;

namespace EncuestaApi.Mappers
{
    public class UserMapper : Profile
    {
        public UserMapper()
        {
            CreateMap<Usuario, UserViewModel>()
            .ForMember(d => d.Id, o => o.MapFrom(c => c.Id))
            .ForMember(d => d.Identification, o => o.MapFrom(c => c.Identificacion))
            .ForMember(d => d.FirstNames, o => o.MapFrom(c => c.Nombres))
            .ForMember(d => d.LastNames, o => o.MapFrom(c => c.Apellidos))
            .ForMember(d => d.UserName, o => o.MapFrom(c => c.NombreUsuario))
            .ForMember(d => d.Password, o => o.MapFrom(c => c.Clave))
            .ForMember(d => d.CreateDate, o => o.MapFrom(c => c.FechaCreacion))
            .ForMember(d => d.LastAccessDate, o => o.MapFrom(c => c.FechaUltimoAcceso))
            .ForMember(d => d.ProfileId, o => o.MapFrom(c => c.PerfilId))
            .ForMember(d => d.Avatar, o => o.MapFrom(c => c.Avatar))
            .ForMember(d => d.Active, o => o.MapFrom(c => c.Activo))

            .ForMember(d => d.Name, o => o.MapFrom(c => $"{c.Nombres} {c.Apellidos}"))
            .ForMember(d => d.Alias, o => o.MapFrom(c => $"{c.Nombres.Substring(0, (StringExtensions.ReturnInt(c.Nombres) == 0 ? c.Nombres.Length : StringExtensions.ReturnInt(c.Nombres)))} {c.Apellidos.Substring(0, (StringExtensions.ReturnInt(c.Apellidos) == 0 ? c.Apellidos.Length : StringExtensions.ReturnInt(c.Apellidos)))}"))
            .ForMember(d => d.Profile, o => o.MapFrom(c => c.Perfil.Nombre));

            CreateMap<UserViewModel, Usuario>()
            .ForMember(d => d.Id, o => o.MapFrom(c => c.Id))
            .ForMember(d => d.Identificacion, o => o.MapFrom(c => c.Identification))
            .ForMember(d => d.Nombres, o => o.MapFrom(c => c.FirstNames))
            .ForMember(d => d.Apellidos, o => o.MapFrom(c => c.LastNames))
            .ForMember(d => d.NombreUsuario, o => o.MapFrom(c => c.UserName))
            .ForMember(d => d.Clave, o => o.MapFrom(c => c.Password))
            .ForMember(d => d.FechaCreacion, o => o.MapFrom(c => c.CreateDate))
            .ForMember(d => d.FechaUltimoAcceso, o => o.MapFrom(c => c.LastAccessDate))
            .ForMember(d => d.PerfilId, o => o.MapFrom(c => c.ProfileId))
            .ForMember(d => d.Avatar, o => o.MapFrom(c => c.Avatar))
            .ForMember(d => d.Activo, o => o.MapFrom(c => c.Active));
        }
    }
}