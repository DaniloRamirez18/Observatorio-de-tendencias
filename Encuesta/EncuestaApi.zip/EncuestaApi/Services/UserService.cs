using System;
using System.Linq;
using System.Collections.Generic;
using EncuestaApi.Entities;
using EncuestaApi.Contexts;
using EncuestaApi.Helpers;
using EncuestaApi.Repository;

namespace EncuestaApi.Services
{
    public interface IUserService
    {
        Usuario Authenticate(string username, string password);
        IEnumerable<Usuario> GetAll();
        IEnumerable<Usuario> GetAll(string includeProperties);
        Usuario GetById(int id);
        Usuario Create(Usuario user, string password);
        bool Update(Usuario user, string password = null);
        void Delete(int id);
    }
    public class UserService : IUserService
    {
        private Context _context;
        private readonly IUserRepository _entityRepository;
        private IQueryable<Usuario> entity;

        public UserService(Context context)
        {
            _context = context;
            _entityRepository = new UserRepository(_context);
        }

        public Usuario Authenticate(string username, string password)
        {
            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                return null;

            // check if password is correct
            //var passwordHash = password.ToSHA256();
            //if (!VerifyPasswordHash(password, passwordHash))
            //    return null;

            //var user = _context.Usuario.SingleOrDefault(x => x.NombreUsuario == username && x.Clave == passwordHash && x.Activo == true);

            var passwordBase = password.Base64_Encode();

            var user = _context.Usuario.SingleOrDefault(x => x.NombreUsuario == username && x.Clave == passwordBase && x.Activo == true);

            // check if username exists
            if (user == null)
                return null;

            // update successful
            UpdateLastDateLogin(user);

            // authentication successful
            return user;
        }

        private void UpdateLastDateLogin(Usuario user)
        {
            try
            {
                user.FechaUltimoAcceso = DateTime.Now;
                _context.Usuario.Update(user);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                var err = ex;
                throw;
            }
        }

        public IEnumerable<Usuario> GetAll()
        {
            return _context.Usuario;
        }

        public IEnumerable<Usuario> GetAll(string includeProperties)
        {
            try
            {
                entity = _entityRepository.GetAll(includeProperties);
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entity;
        }

        public Usuario GetById(int id)
        {
            return _context.Usuario.Find(id);
        }

        public Usuario Create(Usuario user, string password)
        {
            // validation
            if (string.IsNullOrWhiteSpace(password))
                throw new AppException("Password is required");

            if (_context.Usuario.Any(x => x.NombreUsuario == user.NombreUsuario))
                throw new AppException("Username \"" + user.NombreUsuario + "\" is already taken");

            //var passwordHash = password.ToSHA256();
            var passwordBase = password.Base64_Encode();

            user.FechaCreacion = DateTime.Now;
            //user.Clave = passwordHash;
            user.Clave = passwordBase;

            _context.Usuario.Add(user);
            _context.SaveChanges();

            return user;
        }

        public bool Update(Usuario userParam, string password = null)
        {
            var user = _context.Usuario.Find(userParam.Id);
            if (user == null)
                throw new AppException("User not found");

            if (userParam.NombreUsuario != user.NombreUsuario)
            {
                // username has changed so check if the new username is already taken
                if (_context.Usuario.Any(x => x.NombreUsuario == userParam.NombreUsuario))
                    throw new AppException("Username " + userParam.NombreUsuario + " is already taken");
            }
            // update user properties
            user.Identificacion = userParam.Identificacion;
            user.Nombres = userParam.Nombres;
            user.Apellidos = userParam.Apellidos;
            user.NombreUsuario = userParam.NombreUsuario;
            user.Clave = userParam.Clave;
            user.FechaCreacion = DateTime.Now;
            user.Activo = userParam.Activo;

            // update password if it was entered
            if (!string.IsNullOrWhiteSpace(password))
            {
                //var passwordHash = password.ToSHA256();
                //user.Clave = passwordHash;
                var passwordBase = password.Base64_Encode();
                user.Clave = passwordBase;
            }
            _context.Usuario.Update(user);
            _context.SaveChanges();

            return true;
        }

        public void Delete(int id)
        {
            var user = _context.Usuario.Find(id);
            if (user != null)
            {
                _context.Usuario.Remove(user);
                _context.SaveChanges();
            }
        }

        // private helper methods
        private static void CreatePasswordHash(string password, out byte[] passwordHash, out byte[] passwordSalt)
        {
            if (password == null) throw new ArgumentNullException("password");
            if (string.IsNullOrWhiteSpace(password)) throw new ArgumentException("Value cannot be empty or whitespace only string.", "password");
            using (var hmac = new System.Security.Cryptography.HMACSHA512())
            {
                passwordSalt = hmac.Key;
                passwordHash = hmac.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
            }
        }

        private static bool VerifyPasswordHash(string password, string storedHash)
        {
            if (password == null) throw new ArgumentNullException("password");
            if (string.IsNullOrWhiteSpace(password)) throw new ArgumentException("Value cannot be empty or whitespace only string.", "password");
            if (storedHash.Length != 64) throw new ArgumentException("Invalid length of password hash (64 bytes expected).", "passwordHash");
            var computedHash = password.ToSHA256();
            for (int i = 0; i < computedHash.Length; i++)
            {
                if (computedHash[i] != storedHash[i]) return false;
            }
            return true;
        }
    }
}