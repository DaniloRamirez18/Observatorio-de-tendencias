﻿using Microsoft.Extensions.DependencyInjection;

namespace EncuestaApi.Services
{
    public class AautoConfigureService
    {
        public void ConfigureRepositoryWrapper(IServiceCollection services)
        {
            services.AddScoped<IProfileService, ProfileService>();
            services.AddScoped<IQuestionService, QuestionService>();
            services.AddScoped<ISurveyService, SurveyService>();
            services.AddScoped<ISurveyDetailService, SurveyDetailService>();
            services.AddScoped<IUserService, UserService>();
        }
    }
}