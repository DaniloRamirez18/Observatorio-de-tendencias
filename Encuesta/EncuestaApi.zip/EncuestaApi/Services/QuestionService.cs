﻿using System;
using System.Linq;
using System.Data.SqlClient;
using System.Collections.Generic;
using EncuestaApi.Contexts;
using EncuestaApi.Entities;
using EncuestaApi.Helpers;
using EncuestaApi.Repository;
using EncuestaApi.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace EncuestaApi.Services
{
    public interface IQuestionService
    {
        IEnumerable<Pregunta> GetAll();
        IEnumerable<Pregunta> GetAll(string includeProperties);
        IEnumerable<Pregunta> GetAll(int surveyId, string includeProperties);
        Pregunta GetById(int id);
        Pregunta Create(Pregunta entity);
        bool Update(Pregunta entity);
        void Delete(int id);
        IEnumerable<ResultViewModel> GetResult(int EncuestaId);
    }
    public class QuestionService : IQuestionService
    {
        private readonly string nameentity = "Question";
        private readonly Context _context;
        private readonly IQuestionRepository _entityRepository;
        private IQueryable<Pregunta> entity;
        private Pregunta entitycurrent;

        public QuestionService(Context context)
        {
            _context = context;
            _entityRepository = new QuestionRepository(_context);
        }

        public IEnumerable<Pregunta> GetAll()
        {
            try
            {
                entity = _entityRepository.GetAll();
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entity;
        }

        public IEnumerable<Pregunta> GetAll(string includeProperties)
        {
            try
            {
                entity = _entityRepository.GetAll(includeProperties);
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entity;
        }

        public IEnumerable<Pregunta> GetAll(int surveyId, string includeProperties)
        {
            try
            {
                entity = _entityRepository.GetAll(includeProperties).Where(c => c.EncuestaId == surveyId);
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entity;
        }

        public Pregunta GetById(int id)
        {
            try
            {
                entitycurrent = _entityRepository.GetById(id);
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entitycurrent;
        }

        public Pregunta Create(Pregunta entity)
        {
            try
            {
                if (entity != null)
                {
                    _entityRepository.Insert(entity);
                    var result = _entityRepository.UnitOfWork.Commit();
                }
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entity;
        }

        public bool Update(Pregunta entity)
        {
            try
            {
                var entitycurrent = _entityRepository.GetById(entity.Id);
                if (entitycurrent == null)
                    throw new AppException(nameentity + "Not Found");

                // update entity properties
                entitycurrent.EncuestaId = entity.EncuestaId;
                entitycurrent.Titulo = entity.Titulo;
                entitycurrent.TextoAyuda = entity.TextoAyuda;
                entitycurrent.Orden = entity.Orden;

                _entityRepository.Update(entitycurrent);
                var result = _entityRepository.UnitOfWork.Commit();
                return result > 0;
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
                return false;
            }
        }

        public void Delete(int id)
        {
            try
            {
                var entitycurrent = _entityRepository.GetById(id);
                if (entitycurrent == null)
                    throw new AppException(nameentity + "Not Found");

                _entityRepository.Delete(entitycurrent);
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
        }

        public IEnumerable<ResultViewModel> GetResult(int EncuestaId)
        {
            var d = _context.ResultViewModel;

            var Encuesta = new SqlParameter("@EncuestaId", EncuestaId);
            var df = d.FromSql("pa_getResultados @EncuestaId", Encuesta);

            return df;
        }
    }
}