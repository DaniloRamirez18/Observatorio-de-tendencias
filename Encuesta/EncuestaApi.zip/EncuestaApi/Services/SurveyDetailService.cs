﻿using System;
using System.Linq;
using System.Collections.Generic;
using EncuestaApi.Contexts;
using EncuestaApi.Entities;
using EncuestaApi.Helpers;
using EncuestaApi.Repository;

namespace EncuestaApi.Services
{
    public interface ISurveyDetailService
    {
        IEnumerable<EncuestaDetalle> GetAll();
        IEnumerable<EncuestaDetalle> GetAll(string includeProperties);
        EncuestaDetalle GetById(int id);
        EncuestaDetalle Create(EncuestaDetalle entity);
        bool Update(EncuestaDetalle entity);
        void Delete(int id);
    }
    public class SurveyDetailService : ISurveyDetailService
    {
        private readonly string nameentity = "SurveyDetail";
        private readonly Context _context;
        private readonly ISurveyDetailRepository _entityRepository;
        private IQueryable<EncuestaDetalle> entity;
        private EncuestaDetalle entitycurrent;

        public SurveyDetailService(Context context)
        {
            _context = context;
            _entityRepository = new SurveyDetailRepository(_context);
        }

        public IEnumerable<EncuestaDetalle> GetAll()
        {
            try
            {
                entity = _entityRepository.GetAll();
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entity;
        }

        public IEnumerable<EncuestaDetalle> GetAll(string includeProperties)
        {
            try
            {
                entity = _entityRepository.GetAll(includeProperties);
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entity;
        }

        public EncuestaDetalle GetById(int id)
        {
            try
            {
                entitycurrent = _entityRepository.GetById(id);
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entitycurrent;
        }

        public EncuestaDetalle Create(EncuestaDetalle entity)
        {
            try
            {
                if (entity != null)
                {
                    _entityRepository.Insert(entity);
                    var result = _entityRepository.UnitOfWork.Commit();
                }
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
            return entity;
        }

        public bool Update(EncuestaDetalle entity)
        {
            try
            {
                var entitycurrent = _entityRepository.GetById(entity.Id);
                if (entitycurrent == null)
                    throw new AppException(nameentity + "Not Found");

                // update entity properties
                entitycurrent.EncuestaId = entity.EncuestaId;
                entitycurrent.PreguntaId = entity.PreguntaId;
                entitycurrent.Calificacion = entity.Calificacion;
                entitycurrent.FechaInicio = entity.FechaInicio;
                entitycurrent.FechaFinal = entity.FechaFinal;
                entitycurrent.UsuarioId = entity.UsuarioId;

                _entityRepository.Update(entitycurrent);
                var result = _entityRepository.UnitOfWork.Commit();
                return result > 0;
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
                return false;
            }
        }

        public void Delete(int id)
        {
            try
            {
                var entitycurrent = _entityRepository.GetById(id);
                if (entitycurrent == null)
                    throw new AppException(nameentity + "Not Found");

                _entityRepository.Delete(entitycurrent);
            }
            catch (Exception ex)
            {
                Infrastructure.LogManager.LogException(ex);
            }
        }
    }
}