﻿using AutoMapper;
using EncuestaApi.Helpers;
using EncuestaApi.Entities;
using EncuestaApi.Services;
using EncuestaApi.Contexts;
using EncuestaApi.ViewModels;
using System.Linq;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;

namespace EncuestaApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("[controller]")]
    public class QuestionsController : Controller
    {
        private readonly Context _context;
        private readonly IQuestionService _entityService;
        private readonly ILogger _logger;
        private readonly IMapper _mapper;
        private IEnumerable<ResultViewModel> entities;

        public QuestionsController(Context context, IQuestionService entitieservice, ILoggerFactory loggerFactory, IMapper mapper)
        {
            _context = context;
            _entityService = entitieservice;
            _logger = loggerFactory.CreateLogger<QuestionsController>();
            _mapper = mapper;
        }

        //[AllowAnonymous]
        [HttpGet]
        public IActionResult GetAll()
        {
            try
            {
                var entities = _entityService.GetAll("Encuesta");
                var viewmodels = _mapper.Map<IList<QuestionViewModel>>(entities);
                if (viewmodels == null)
                {
                    return NotFound();
                }
                return Ok(viewmodels);
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        //[AllowAnonymous]
        [HttpGet("getcount")]
        public IActionResult GetCount()
        {
            try
            {
                var res = _entityService.GetAll().Count();
                return Ok(res);
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        //[AllowAnonymous]
        [HttpGet("getsurveyid/{surveyid}")]
        public IActionResult GetAll(int surveyid)
        {
            try
            {
                var entities = _entityService.GetAll(surveyid, "Encuesta");
                var viewmodels = _mapper.Map<IList<QuestionViewModel>>(entities);
                if (viewmodels == null)
                {
                    return NotFound();
                }
                return Ok(viewmodels);
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        //[AllowAnonymous]
        [HttpGet("getcountsurveyid/{surveyid}")]
        public IActionResult GetCountSurvey(int surveyid)
        {
            try
            {
                var res = _entityService.GetAll().Where(c => c.EncuestaId == surveyid).Count();
                return Ok(res);
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        //[AllowAnonymous]
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            try
            {
                var entity = _entityService.GetById(id);
                var viewmodel = _mapper.Map<QuestionViewModel>(entity);
                if (viewmodel == null)
                {
                    return NotFound();
                }
                return Ok(viewmodel);
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost]
        public IActionResult Create([FromBody]QuestionViewModel viewmodel)
        {
            // map dto to entity
            var entity = _mapper.Map<Pregunta>(viewmodel);
            try
            {
                // save 
                _entityService.Create(entity);
                return Ok();
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody]QuestionViewModel viewmodel)
        {
            // map dto to entity and set id
            var entity = _mapper.Map<Pregunta>(viewmodel);
            entity.Id = id;
            try
            {
                // save 
                _entityService.Update(entity);
                return Ok();
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _entityService.Delete(id);
                return Ok();
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        //[AllowAnonymous]
        [HttpGet("getresultsurveyid/{surveyid}")]
        public IActionResult GetResult(int surveyid)
        {
            try
            {
                entities = _entityService.GetResult(surveyid);

                var viewmodels = _mapper.Map<IList<ResultViewModel>>(entities);
                return Ok(viewmodels);
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new
                {
                    message = ex.Message
                });
            }
        }
    }
}