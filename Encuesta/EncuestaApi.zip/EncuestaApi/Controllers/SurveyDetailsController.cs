﻿using AutoMapper;
using EncuestaApi.ViewModels;
using EncuestaApi.Helpers;
using EncuestaApi.Entities;
using EncuestaApi.Services;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Logging;
using System.Linq;

namespace EncuestaApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("[controller]")]
    public class SurveyDetailsController : Controller
    {
        private readonly ISurveyDetailService _entityService;
        private readonly ILogger _logger;
        private readonly IMapper _mapper;

        public SurveyDetailsController(ISurveyDetailService entitieservice, ILoggerFactory loggerFactory, IMapper mapper)
        {
            _entityService = entitieservice;
            _logger = loggerFactory.CreateLogger<SurveyDetailsController>();
            _mapper = mapper;
        }

        //[AllowAnonymous]
        [HttpGet]
        public IActionResult GetAll()
        {
            try
            {
                var entities = _entityService.GetAll();
                var viewmodels = _mapper.Map<IList<SurveyDetailViewModel>>(entities);
                if (viewmodels == null)
                {
                    return NotFound();
                }
                return Ok(viewmodels);
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        //[AllowAnonymous]
        [HttpGet("getcount")]
        public IActionResult GetCount()
        {
            try
            {
                var res = _entityService.GetAll().Count();
                return Ok(res);
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        //[AllowAnonymous]
        [HttpGet("getcountsurveyid/{surveyid}")]
        public IActionResult GetCountSurvey(int surveyid)
        {
            try
            {
                var res = _entityService.GetAll().Where(c => c.EncuestaId == surveyid).Count();
                return Ok(res);
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        //[AllowAnonymous]
        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            try
            {
                var entity = _entityService.GetById(id);
                var viewmodel = _mapper.Map<SurveyDetailViewModel>(entity);
                if (viewmodel == null)
                {
                    return NotFound();
                }
                return Ok(viewmodel);
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPost]
        public IActionResult Create([FromBody]SurveyDetailViewModel viewmodel)
        {
            // map dto to entity
            var entity = _mapper.Map<EncuestaDetalle>(viewmodel);
            try
            {
                // save 
                _entityService.Create(entity);
                return Ok();
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody]SurveyDetailViewModel viewmodel)
        {
            // map dto to entity and set id
            var entity = _mapper.Map<EncuestaDetalle>(viewmodel);
            entity.Id = id;
            try
            {
                // save 
                _entityService.Update(entity);
                return Ok();
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _entityService.Delete(id);
                return Ok();
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}