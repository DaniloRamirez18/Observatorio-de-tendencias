﻿using AutoMapper;
using System;
using System.Text;
using System.Security.Claims;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Authorization;
using EncuestaApi.Helpers;
using EncuestaApi.ViewModels;
using EncuestaApi.Entities;
using EncuestaApi.Services;

namespace EncuestaApi.Controllers
{
    [Authorize]
    [ApiController]
    [Route("[controller]")]
    public class UsersController : Controller
    {
        private readonly IUserService _entityService;
        private readonly IProfileService _profileService;
        private readonly ILogger _logger;
        private readonly IMapper _mapper;
        private readonly AppSettings _appSettings;

        public UsersController(IUserService entitieservice, IProfileService profileService, ILoggerFactory loggerFactory, IMapper mapper, IOptions<AppSettings> appSettings)
        {
            _entityService = entitieservice;
            _profileService = profileService;
            _logger = loggerFactory.CreateLogger<UsersController>();
            _mapper = mapper;
            _appSettings = appSettings.Value;
        }

        [AllowAnonymous]
        [HttpPost("authenticate")]
        public IActionResult Authenticate([FromBody]UserViewModel viewmodel)
        {
            try
            {
                var user = _entityService.Authenticate(viewmodel.UserName, viewmodel.Password);
                if (user == null)
                    return BadRequest(new { message = "Username or Password is incorrect" });

                var tokenHandler = new JwtSecurityTokenHandler();
                var key = Encoding.ASCII.GetBytes(_appSettings.Secret);
                var tokenDescriptor = new SecurityTokenDescriptor
                {
                    Subject = new ClaimsIdentity(new Claim[]
                    {
                    new Claim(ClaimTypes.Name, user.Id.ToString())
                    }),
                    Expires = DateTime.UtcNow.AddDays(1),
                    SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
                };
                var token = tokenHandler.CreateToken(tokenDescriptor);
                var tokenString = tokenHandler.WriteToken(token);

                // return basic user info (without password) and token to store client side
                return Ok(new
                {
                    user.Id,
                    Identification = user.Identificacion,
                    FirstNames = user.Nombres,
                    LastNames = user.Apellidos,
                    UserName = user.NombreUsuario,
                    Password = user.Clave,
                    CreateDate = user.FechaCreacion,
                    LastAccessDate = user.FechaUltimoAcceso,
                    ProfileId = user.PerfilId,
                    Avatar = user.Avatar,
                    Active = user.Activo,
                    Name = $"{user.Nombres} {user.Apellidos}",
                    Alias = $"{user.Nombres.Substring(0, (StringExtensions.ReturnInt(user.Nombres) == 0 ? user.Nombres.Length : StringExtensions.ReturnInt(user.Nombres)))} {user.Apellidos.Substring(0, (StringExtensions.ReturnInt(user.Apellidos) == 0 ? user.Apellidos.Length : StringExtensions.ReturnInt(user.Apellidos)))}",
                    Profile = _profileService.GetById(user.PerfilId).Nombre,
                    Token = tokenString
                });
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        [AllowAnonymous]
        [HttpPost("register")]
        public IActionResult Register([FromBody]UserViewModel viewmodel)
        {
            // map dto to entity
            var entity = _mapper.Map<Usuario>(viewmodel);
            try
            {
                // save 
                var entitycurrent = _entityService.Create(entity, viewmodel.Password);
                return Ok(entitycurrent);
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult GetAll()
        {
            try
            {
                var entities = _entityService.GetAll("Perfil");
                var viewmodel = _mapper.Map<IList<UserViewModel>>(entities);
                if (viewmodel == null)
                {
                    return NotFound();
                }
                return Ok(viewmodel);
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public IActionResult GetById(int id)
        {
            try
            {
                var entity = _entityService.GetById(id);
                var viewmodel = _mapper.Map<UserViewModel>(entity);
                if (viewmodel == null)
                {
                    return NotFound();
                }
                return Ok(viewmodel);
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody]UserViewModel viewmodel)
        {
            // map dto to entity and set id
            var entity = _mapper.Map<Usuario>(viewmodel);
            entity.Id = id;
            try
            {
                // save 
                _entityService.Update(entity, viewmodel.Password);
                return Ok();
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            try
            {
                _entityService.Delete(id);
                return Ok();
            }
            catch (AppException ex)
            {
                // return error message if there was an exception
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }

        [AllowAnonymous]
        [HttpGet("status")]
        public IActionResult Status(int id)
        {
            var statu = "Estado del Servicio...OK";
            try
            {
                _logger.LogInformation("Estado del Servicio...OK");
                return Ok(statu);
            }
            catch (AppException ex)
            {
                _logger.LogError(ex.Message);
                return BadRequest(new { message = ex.Message });
            }
        }
    }
}