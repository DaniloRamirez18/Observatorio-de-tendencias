﻿namespace EncuestaApi.ViewModels
{
    public class QuestionViewModel
    {
        public int Id { get; set; }
        public int SurveyId { get; set; }
        public string Title { get; set; }
        public string TextHelp { get; set; }
        public int Order { get; set; }

        public string Survey { get; set; }
    }
}