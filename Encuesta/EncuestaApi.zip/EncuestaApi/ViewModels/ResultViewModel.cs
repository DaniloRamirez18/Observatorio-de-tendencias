﻿namespace EncuestaApi.ViewModels
{
    public class ResultViewModel
    {
        public int Id { get; set; }
        public int EncuestaId { get; set; }
        public string Nombre { get; set; }
        public int Orden { get; set; }
        public string Titulo { get; set; }
        public int Cantidad { get; set; }
        public int Total { get; set; }
    }
}