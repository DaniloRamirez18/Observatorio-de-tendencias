using System;

namespace EncuestaApi.ViewModels
{
    public class UserViewModel
    {
        public int Id { get; set; }
        public string Identification { get; set; }
        public string FirstNames { get; set; }
        public string LastNames { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public DateTime CreateDate { get; set; } = DateTime.Now;
        public DateTime LastAccessDate { get; set; } = DateTime.Now;
        public int ProfileId { get; set; }
        public string Avatar { get; set; }
        public bool Active { get; set; }

        public string Name { get; set; }
        public string Alias { get; set; }
        public string Profile { get; set; }
    }
}